import Vue from 'vue';
import App from './App.vue';
import './app.scss';
import '../home/home.scss';
import title from '../../APPcommon/modules/title';

new Vue({
    el:'#app',
    template:'<App/>',
    components:{App},
    created:function(){
        alert('about')
        // this.$parent.data.titleMsg="这里是about页面"
        title('这里是about页面');
        alert('fsafsddaf')
    }
})