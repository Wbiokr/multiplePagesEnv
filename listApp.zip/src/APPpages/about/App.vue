<template>
    <div id="app">
        <img src="./img/num1.png" alt="">
    </div>
</template>
<script>
    export default{
        
    }
</script>
