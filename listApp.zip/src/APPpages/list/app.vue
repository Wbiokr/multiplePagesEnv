<template>
    <div id="app"></div>
</template>
<script>
    export default{
        
    }
</script>
<style lang="">
    #app{
        height:100%;
        width:50%;
    }
</style>